# Andrei Cocan
# Python 3.11.1
# Activity 3

# Variables
var1 = 4
var2 = 2.5
var3 = 10

# Mathematics Operators

print(var1 + var2)
print(var3 - var1)
print(var1 * var3)
print(var3 / var2)
print(var3 ** var1)
print(var3 % var1)

# Rational Operators

print(var3 > var2)
print(var3 < var2)
print(var3 >= var1)
print(var3 <= var1)
print(var3 == var3)
print(var3 != var3)