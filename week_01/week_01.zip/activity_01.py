# Andrei Cocan
# Python 3.11.1
# Activity 1

print('\n Hello World\n')